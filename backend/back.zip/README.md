# Calvin's Backend

- steps to start calvin's server
  * source app_env                  to make collection, database and bucket name an env variable
  * npm install                     to install the apps dependencies
  * node other/setup.js             to create new collection, database and bucket with the name described in the app_env file
  * node conversationController.js  to start the server
