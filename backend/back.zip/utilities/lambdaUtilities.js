const AWS = require('aws-sdk')

var lambda = new AWS.Lambda({
  apiVersion: '2015-03-31',
})


function addPermission () {

}

function createFunction () {

}

function deleteFunction () {

}

function getFunction () {

}

function listFunctions () {

}
