# Calvin's Backend
- Remember to source the app_env folder before running code to make the NAME variable available to the process
- Run node /other/setup.js to create a new calvin system from scratch with the name provided in the app_env file
- Run npm run dev to begin nodemon and subsequently the application 
- The express server is an https server meaning you will have to validate the address when the website loads
